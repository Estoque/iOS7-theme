/*
You set the background-image to main element, and the rest is taken care of.

The principle is simple. You inhertit the backgrounds, and turn the shit until it aligns.
*/