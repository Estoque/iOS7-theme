A Pen created at CodePen.io. You can find this one at http://codepen.io/Darsain/pen/Cxawq.

 Texturized hexagon with a proper cursor collision. Done with child & pseudo elements, background inheritance, and 2D transforms.

Same thing accomplished with CSS clip-path: polygon() here: http://codepen.io/Darsain/pen/IqjFe